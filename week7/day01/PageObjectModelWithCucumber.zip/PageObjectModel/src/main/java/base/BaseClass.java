package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.LearnCIExcel;

public class BaseClass extends AbstractTestNGCucumberTests {

	// private static final ThreadLocal chDriver = new ThreadLocal();
	
	public String fileName;

	private static final ThreadLocal<RemoteWebDriver> chDriver = new ThreadLocal<RemoteWebDriver>();

	public void setDriver() {
		// Sets the current thread's copy of this thread-local variable
		chDriver.set(new ChromeDriver());
	}

	public RemoteWebDriver getDriver() {
		// Returns the value in the current thread's copy of this thread-local variable
		return chDriver.get();
	}

	
	@BeforeMethod
	public void preCondition() {
		/*
		 * ChromeOptions options = new ChromeOptions(); options.addArguments("--guest");
		 */
		setDriver();
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}

	@AfterMethod
	public void postCondition() {
		getDriver().quit();
	}

	@DataProvider(name = "getValue")
	public String[][] fetchData() throws IOException {
		return LearnCIExcel.readExcel(fileName);
	}

}
