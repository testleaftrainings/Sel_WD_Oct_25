package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class MyHomePage extends BaseClass {

	public MyHomePage ClickLeads() {
		getDriver().findElement(By.linkText("Leads")).click();
		return this;
	}
}