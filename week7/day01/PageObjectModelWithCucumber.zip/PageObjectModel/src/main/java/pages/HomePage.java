package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class HomePage extends BaseClass {
	
	public MyHomePage clickCRMSFA() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage();
	}

	public LoginPage clickLogOut() throws InterruptedException {
		Thread.sleep(3000);
		getDriver().findElement(By.xpath("//input[@class='decorativeSubmit']")).click();
		return new LoginPage();
	}

}
