package runner;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_001_Leads extends BaseClass{

	@Test 
	public void TC_001_Lead() {
		
		LoginPage lp = new LoginPage();
		lp.userName().passWord().loginButton()
		.clickCRMSFA()
		.ClickLeads();
	}

}
