package pages;

import org.openqa.selenium.By;

import base.BaseClass;

public class HomePage extends BaseClass{
	
	public MyHomePage clickCRMSFA() {
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage();
	}
	
	public LoginPage clickLogOut() {
		driver.findElement(By.xpath("//input[@class='decorativeSubmit']")).click();
		return new LoginPage();
	}

}
