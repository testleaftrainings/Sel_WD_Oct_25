package stepDefenition;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDef {

	ChromeDriver driver;

	@Given("launch the browser")
	public void launch_the_browser() {
		driver = new ChromeDriver();
	}

	@Given("load the given URL")
	public void load_the_given_url() {
		driver.get("http://leaftaps.com/opentaps/");
	}

	@When("enter the username {string}")
	public void enter_the_username(String uName) {
		driver.findElement(By.id("username")).sendKeys(uName);
	}

	@When("enter the password {string}")
	public void enter_the_password(String pWord) {
		driver.findElement(By.id("password")).sendKeys(pWord);
	}

	@When("Click on the Login button")
	public void click_on_the_login_button() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}

	@Then("It will navigate to the next page")
	public void it_will_navigate_to_the_next_page() {
		String title = driver.getTitle();
		System.out.println(title);
	}
	
	@But("It will not navigate to the next page")
	public void it_will_not_navigate_to_the_next_page() {
	   System.out.println("Password incorrect");
	}

}
