package hooks;

import java.time.Duration;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import base.BaseClass;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class HooksImplementation { //extends BaseClass {

	// Step 1: Create 2 methods - 1.preCondition 2.postCondition

	// Step2: implement the annotation @Before & @After

	// Step3: implement the common line of codes inside methods.

	// Step4 : Declare the ChromeDriver as global.
	
		public ChromeDriver driver;

		@Before
		public void preCondition() {
			
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--guest");
			driver = new ChromeDriver(options);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			driver.get("http://leaftaps.com/opentaps/");
		}
		
		@After
		public void postCondition() {
			
			driver.close();
		}
}
